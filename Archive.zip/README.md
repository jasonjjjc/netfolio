My Portfolio

This is my portfolio website, it is a single page application that is built using HTML and SASS. It is a responsive website that is designed to work on all devices.


## Installation

Open the index.html file in your browser of choice.


## Usage

This website is designed to showcase my skills and projects that I have worked on. It is also designed to be a contact point for potential employers to get in touch with me.


## Contributing

Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.


## License

See LICENSE file for details.


## Project Status

This project is currently in development. Users can view the website but it is not yet complete.


## Acknowledgements

This project was built using the following technologies:

- HTML
- SASS


## Contact

linkedin.com/in/jason-chalangary# netfolio
